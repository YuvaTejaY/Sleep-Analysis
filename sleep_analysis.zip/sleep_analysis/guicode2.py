from tkinter import *
import tkinter.messagebox
import datetime
from PIL import Image, ImageTk

def detect_sleep_disorders(row):
    disorders = []

    # Insomnia
    if ((float(row['Sleep duration']) < 6 or row['Trouble Falling Asleep'] == 'yes') and
            row['Wake Earlier'] == 'yes' and row['Difficulty Staying Asleep'] == 'yes'):
        disorders.append("Insomnia")

    # Sleep Apnea
    if (row['Snoring'] == 'yes' and
            (int(row['Awakenings']) > 5 or row['Daytime Sleepiness'] == 'yes')):
        disorders.append("Sleep Apnea")

    # Hypersomnia
    if (float(row['Sleep duration']) > 9 and
            row['Daytime Sleepiness'] == 'yes' and int(row['Awakenings']) <= 1):
        disorders.append("Hypersomnia")

    # Circadian Rhythm Disorders
    if ((row['Wake Earlier'] == 'Y' or row['Trouble Falling Asleep'] == 'yes') and
            (int(row['Bedtime'].split(":")[0]) >= 23 or int(row['Wakeup time'].split(":")[0]) <= 4)):
        disorders.append("Circadian Rhythm Disorders")

    # Parasomnia
    if row['Unusual Behavior'] == 'yes':
        disorders.append("Parasomnia")

    # Restless Leg Syndrome (RLS)
    if (row['Leg Discomfort'] == 'yes' and row['Difficulty Staying Asleep'] == 'yes'):
        disorders.append("Restless Leg Syndrome (RLS)")

    return disorders

class Sleep:
    def __init__(self, master, *args, **kwargs):
        # for heading
        self.master = master

        # Get window dimensions
        window_width = master.winfo_screenwidth()
        window_height = master.winfo_screenheight()

        # Canvas for background image
        self.canvas = Canvas(master, width=window_width, height=window_height)
        self.bg_img = Image.open("C:/Users/TEJA/Desktop/sleep/sleeping_lady.jpg")
        self.bg_img_resized = self.bg_img.resize((window_width, window_height))
        self.bg_img_tk = ImageTk.PhotoImage(self.bg_img_resized)
        self.canvas.create_image(0, 0, anchor=NW, image=self.bg_img_tk)
        self.canvas.pack(fill="both", expand=True)

        # Heading
        self.canvas.create_text(700, 50, text="Sleep Analysis", font=("arial", 50, "bold"), fill="gray10")

        # Labels (on canvas)
        self.canvas.create_text(220, 120, text="Enter Age", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 160, text="Bedtime", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 200, text="Wakeup time", font=("arial",15, "bold"), fill="gray10")
        self.canvas.create_text(220, 240, text="Sleep duration", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 280, text="Awakenings", font=("arial",15, "bold"), fill="gray10")
        self.canvas.create_text(220, 320, text="Daytime Sleepiness", font=("arial",15, "bold"), fill="gray10")
        self.canvas.create_text(220, 360, text="Trouble Falling Asleep", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 400, text="Snoring", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 440, text="Leg Discomfort", font=("arial",15, "bold"), fill="gray10")
        self.canvas.create_text(220, 480, text="Unusual Behavior", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 520, text="Wake Earlier", font=("arial", 15, "bold"), fill="gray10")
        self.canvas.create_text(220, 560, text="Difficulty Staying Asleep", font=("arial", 15, "bold"), fill="gray10")

        # Entries
        self.Age_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        self.Age_e.place(x=400, y=110)

        self.Bedtime_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        self.Bedtime_e.place(x=400, y=150)

        self.Wakeup_time_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        self.Wakeup_time_e.place(x=400, y=190)

        self.Sleep_duration_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        self.Sleep_duration_e.place(x=400, y=230)

        self.Awakenings_e = Entry(master, width=25, font=("arial",15, "bold"), bd=0, highlightthickness=0)
        self.Awakenings_e.place(x=400, y=270)
        #
        # self.Daytime_Sleepiness_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        # self.Daytime_Sleepiness_e.place(x=650, y=310)
        self.Daytime_Sleepiness_status=StringVar(value="no")
        Daytime_Sleepiness_button = Radiobutton(
            root, text="Yes", variable=self.Daytime_Sleepiness_status, value="yes", font=("Arial", 15,"bold"),fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Daytime_Sleepiness_button.place(x=400, y=310)

        not_Daytime_Sleepiness_button = Radiobutton(
            root, text="No", variable=self.Daytime_Sleepiness_status, value="no", font=("Arial", 15,"bold"),fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Daytime_Sleepiness_button.place(x=500, y=310)
        #
        # self.Trouble_Falling_Asleep_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        # self.Trouble_Falling_Asleep_e.place(x=650, y=350)
        self.Trouble_Falling_Asleep_status = StringVar(value="no")
        Trouble_Falling_Asleep_button = Radiobutton(
            root, text="Yes", variable=self.Trouble_Falling_Asleep_status, value="yes", font=("Arial", 15, "bold"), fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Trouble_Falling_Asleep_button.place(x=400, y=350)

        not_Trouble_Falling_Asleep_button = Radiobutton(
            root, text="No", variable=self.Trouble_Falling_Asleep_status, value="no", font=("Arial", 15, "bold"), fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Trouble_Falling_Asleep_button.place(x=500, y=350)

        #
        # self.Snoring_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        # self.Snoring_e.place(x=650, y=390)
        self.Snoring_status = StringVar(value="no")
        Snoring_button = Radiobutton(
            root, text="Yes", variable=self.Snoring_status, value="yes", font=("Arial", 15, "bold"),
            fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Snoring_button.place(x=400, y=390)

        not_Snoring_button = Radiobutton(
            root, text="No", variable=self.Snoring_status, value="no", font=("Arial", 15, "bold"), fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Snoring_button.place(x=500, y=390)


        # self.Leg_Discomfort_e = Entry(master, width=25, font=("arial",15, "bold"), bd=0, highlightthickness=0)
        # self.Leg_Discomfort_e.place(x=650, y=430)

        self.Leg_Discomfort_status = StringVar(value="no")
        Leg_Discomfort_button = Radiobutton(
            root, text="Yes", variable=self.Leg_Discomfort_status, value="yes", font=("Arial", 15, "bold"),
            fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Leg_Discomfort_button.place(x=400, y=430)

        not_Leg_Discomfort_button = Radiobutton(
            root, text="No", variable=self.Leg_Discomfort_status, value="no", font=("Arial", 15, "bold"), fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Leg_Discomfort_button.place(x=500, y=430)

        # self.Unusual_Behavior_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        # self.Unusual_Behavior_e.place(x=650, y=470)

        self.Unusual_Behavior_status = StringVar(value="no")
        Unusual_Behavior_button = Radiobutton(
            root, text="Yes", variable=self.Unusual_Behavior_status, value="yes", font=("Arial", 15, "bold"),
            fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Unusual_Behavior_button.place(x=400, y=470)

        not_Unusual_Behavior_button = Radiobutton(
            root, text="No", variable=self.Unusual_Behavior_status, value="no", font=("Arial", 15, "bold"), fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Unusual_Behavior_button.place(x=500, y=470)

        # self.Wake_Earlier_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        # self.Wake_Earlier_e.place(x=650, y=510)

        self.Wake_Earlier_status = StringVar(value="no")
        Wake_Earlier_button = Radiobutton(
            root, text="Yes", variable=self.Wake_Earlier_status, value="yes", font=("Arial", 15, "bold"),
            fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Wake_Earlier_button.place(x=400, y=510)

        not_Wake_Earlier_button = Radiobutton(
            root, text="No", variable=self.Wake_Earlier_status, value="no", font=("Arial", 15, "bold"), fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Wake_Earlier_button.place(x=500, y=510)

        # self.Difficulty_Staying_e = Entry(master, width=25, font=("arial", 15, "bold"), bd=0, highlightthickness=0)
        # self.Difficulty_Staying_e.place(x=650, y=550)
        self.Difficulty_Staying_status = StringVar(value="no")
        Difficulty_Staying_button = Radiobutton(
            root, text="Yes", variable=self.Difficulty_Staying_status, value="yes", font=("Arial", 15, "bold"),
            fg="gray10", bg="#D3D3D3", bd=0, highlightthickness=0
        )
        Difficulty_Staying_button.place(x=400, y=550)

        not_Difficulty_Staying_button = Radiobutton(
            root, text="No", variable=self.Difficulty_Staying_status, value="no", font=("Arial", 15, "bold"), fg="gray10" ,bg="#D3D3D3", bd=0, highlightthickness=0
        )
        not_Difficulty_Staying_button.place(x=500, y=550)
        

        # Date label
        self.canvas.create_text(1150, 30, text="Today's time: " + str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                                font=("arial", 12), fill="gray10")
        submit_button = Button(root, text="Submit", font=("Arial", 14,"bold"),bg="ivory4",command=self.submit_data)
        submit_button.place(x=500,y=600)
        refresh_button = Button(root, text="Refresh", font=("Arial", 14, "bold"), bg="ivory4",command=self.refresh)
        refresh_button.place(x=700, y=600)
        self.canvas.create_text(900, 120, text="Note:", font=("arial", 15, "bold"), fill="gray10")
        self.txtbox = Text(master, height=12, width=40)
        self.txtbox.place(x=875, y=130)
        self.txtbox.insert(END,"For 'Bedtime' and 'Wakeup Time',use the format 'HH:MM' (24-hour clock).\n"
                               "Example: For 10:30 PM, enter 22:30. For 6:15 AM, enter 06:15.")
        self.canvas.create_text(1100, 450, text="A good laugh and a long sleep \nare the best cures in the doctor's book", font=("Times", 17, "italic"))

        #for submit button

    def submit_data(self,*args,**kwargs):
        self.Age=self.Age_e.get()
        self.Bedtime= self.Bedtime_e.get()
        self.Wakeup_time = self.Wakeup_time_e.get()
        self.Sleep_duration = self.Sleep_duration_e.get()
        self.Awakenings = self.Awakenings_e.get()
        self.Daytime_Sleepiness = self.Daytime_Sleepiness_status.get()
        self.Snoring= self.Snoring_status.get()
        self.Trouble_Falling_Asleep= self.Trouble_Falling_Asleep_status.get()
        self.Leg_Discomfort= self.Leg_Discomfort_status.get()
        self.Unusual_Behavior = self.Unusual_Behavior_status.get()
        self.Wake_Earlier = self.Wake_Earlier_status.get()
        self.Difficulty_Staying = self.Difficulty_Staying_status.get()

        if not all([self.Age, self.Bedtime, self.Wakeup_time, self.Sleep_duration, self.Awakenings]):
            tkinter.messagebox.showerror("Error", "Please fill in all the fields.")
            return



            # # Detect sleep disorders using the row
            # detect_sleep_disorders(row)

            # Prepare the data string
        # data = (
        #     f"Age: {self.Age}\n"
        #     f"Bedtime: {self.Bedtime}\n"
        #     f"Wakeup Time: {self.Wakeup_time}\n"
        #     f"Sleep Duration: {self.Sleep_duration}\n"
        #     f"Awakenings: {self.Awakenings}\n"
        #     f"Daytime Sleepiness: {self.Daytime_Sleepiness}\n"
        #     f"Trouble Falling Asleep: {self.Trouble_Falling_Asleep}\n"
        #     f"Snoring: {self.Snoring}\n"
        #     f"Leg Discomfort: {self.Leg_Discomfort}\n"
        #     f"Unusual Behavior: {self.Unusual_Behavior}\n"
        #     f"Wake Earlier: {self.Wake_Earlier}\n"
        #     f"Difficulty Staying Asleep: {self.Difficulty_Staying}\n"
        # )


        # Insert data into the Text widget
        # self.txtbox.delete(1.0, END)  # Clear the Text widget
        # self.txtbox.insert(END, data)
        data = {
            'Age': self.Age,
            'Bedtime': self.Bedtime,
            'Wakeup time': self.Wakeup_time,
            'Sleep duration': self.Sleep_duration,
            'Awakenings': self.Awakenings,
            'Daytime Sleepiness': self.Daytime_Sleepiness,
            'Snoring': self.Snoring,
            'Trouble Falling Asleep': self.Trouble_Falling_Asleep,
            'Leg Discomfort': self.Leg_Discomfort,
            'Unusual Behavior': self.Unusual_Behavior,
            'Wake Earlier': self.Wake_Earlier,
            'Difficulty Staying Asleep': self.Difficulty_Staying
        }
        disorders = detect_sleep_disorders(data)

        self.display_results(data, disorders)

    def display_results(self, data, disorders):
        # self.txtbox.delete(1.0, END)
        # self.txtbox.insert(END, "Detected Disorders:\n")
        # self.txtbox.insert(END, ", ".join(disorders) + "\n\n" if disorders else "None\n\n")
        # self.txtbox.insert(END, "Recommendations:\n")
        # for disorder in disorders:
        #     if disorder == "Insomnia":
        #         self.txtbox.insert(END, "- Maintain a consistent sleep schedule.\n-Getting in some daily physical activity is one of the best remedies for insomnia\n-This goes for alcohol and caffeine too. Both caffeine and alcohol can affect the quality of your sleep or make it hard for you to fall asleep. Stop drinking caffeine by mid-afternoon and avoid alcohol after dinner.One of the most popular remedies for insomnia is to drink warm milk or chamomile tea before bedtime.\n")
        #     elif disorder == "Sleep Apnea":
        #         self.txtbox.insert(END, "- Consult a doctor for CPAP therapy.\n")
        #     elif disorder == "Hypersomnia":
        #         self.txtbox.insert(END, "- Limit naps and seek professional advice.\n-Avoid alcohol before bedtime. \n-Avoid caffeinated products (including coffee, cola, tea, chocolate, and various over-the-counter medicines) within several hours of bedtime.\n-Avoid tobacco and nicotine-containing products near bedtime.\n")
        #     elif disorder == "Circadian Rhythm Disorders":
        #         self.txtbox.insert(END, "- Gradually adjust your sleep-wake cycle.\n-Avoid bright lights and electronic screens close to bedtime.\n-Avoid long or late-day naps, as they can disrupt your natural sleep-wake cycle.\n")
        #     elif disorder == "Parasomnia":
        #         self.txtbox.insert(END, "- Ensure a safe sleep environment.\n-Sleep in separate beds if the person with parasomnia displays aggressive behaviors \n-Install alarms on windows and doors for sleepwalkers.\n")
        #     elif disorder == "Restless Leg Syndrome (RLS)":
        #         self.txtbox.insert(END, "- Stretch legs before bed and consult a doctor.\n")
        new_window = Toplevel()
        new_window.title("Sleep Analysis Results")

        # Create a Text widget
        txtbox = Text(new_window, wrap=WORD, width=80, height=20)
        txtbox.pack(padx=10, pady=10)

        # Insert data into the Text widget
        txtbox.insert(END, "Detected Disorders:\n")
        txtbox.insert(END, ", ".join(disorders) + "\n\n" if disorders else "None\n\n")
        txtbox.insert(END, "Recommendations:\n")

        for disorder in disorders:
            if disorder == "Insomnia":
                txtbox.insert(END, "- Maintain a consistent sleep schedule.\n"
                                   "- Get daily physical activity.\n"
                                   "- Avoid caffeine and alcohol near bedtime.\n"
                                   "- Drink warm milk or chamomile tea before bed.\n")
            elif disorder == "Sleep Apnea":
                txtbox.insert(END, "- Consult a doctor for CPAP therapy.\n")
            elif disorder == "Hypersomnia":
                txtbox.insert(END, "- Limit naps and seek professional advice.\n"
                                   "- Avoid alcohol and caffeine before bedtime.\n"
                                   "- Avoid nicotine near bedtime.\n")
            elif disorder == "Circadian Rhythm Disorders":
                txtbox.insert(END, "- Gradually adjust your sleep-wake cycle.\n"
                                   "- Avoid bright lights and screens before bedtime.\n"
                                   "- Avoid late-day naps.\n")
            elif disorder == "Parasomnia":
                txtbox.insert(END, "- Ensure a safe sleep environment.\n"
                                   "- Sleep separately if aggressive behaviors occur.\n"
                                   "- Install alarms for sleepwalkers.\n")
            elif disorder == "Restless Leg Syndrome (RLS)":
                txtbox.insert(END, "- Stretch legs before bed and consult a doctor.\n")

        # Make the Text widget read-only
        txtbox.config(state=DISABLED)
    def refresh(self,*args,**kwargs):
        self.Age_e.delete(0, 'end')
        self.Bedtime_e.delete(0, 'end')
        self.Wakeup_time_e.delete(0, 'end')
        self.Sleep_duration_e.delete(0, 'end')
        self.Awakenings_e.delete(0, 'end')

root = Tk()
b = Sleep(root)

root.geometry("1366x768")  # Standard screen resolution
root.title("Sleep Analysis")
root.mainloop()
